
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (req,res)=>res.send("Backend running"));

app.get('/api/products',(req,res)=>{
 res.json([{name:"Laptop",price:50000},{name:"Phone",price:20000}]);
});

app.listen(5000,()=>console.log("Server started on 5000"));
